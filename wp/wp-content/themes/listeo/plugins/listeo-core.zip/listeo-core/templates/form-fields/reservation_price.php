<!-- Section -->
<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
?>
<div class="row">
	<div class="col-md-3">
		<table id="reservation-pricing-list-container">
			<tr class="reservation-pricing-list-item pattern">
				<td>
            		<div class="fm-input reservation-pricing-price paid-reservation"><input name="_reservation_price" type="number" placeholder="Price" data-unit="USD" /></div>
				</td>
			</tr>
		</table>
	</div>
</div>