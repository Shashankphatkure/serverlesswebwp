<div class="col-md-6 col-xs-6">
					<!-- Layout Switcher -->
	<div class="layout-switcher">
		<a href="#" class="grid"><i class="fa fa-th"></i></a>
		<a href="#" class="list active"><i class="fa fa-align-justify"></i></a>
	</div>
</div>
<!-- Sorting / Layout Switcher -->